import pygame
import sys
import random
from words import *

pygame.init()


WIDTH, HEIGHT = 633, 900
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))


pygame.display.set_caption("Wordle Remake - Main Menu")
GUESSED_LETTER_FONT = pygame.font.Font("../WORDLE/ConcertOne-Regular.ttf", 50)
AVAILABLE_LETTER_FONT = pygame.font.Font("../WORDLE/ConcertOne-Regular.ttf", 25)
BACK_LETTER_FONT = pygame.font.Font("../WORDLE/ConcertOne-Regular.ttf", 15)


attempts_counter = {
    1: 0,
    2: 0,
    3: 0,
    4: 0,
    5: 0,
    6: 0
}


wins = 0

# Other variables
current_guess = []
current_guess_string = ""
current_letter_bg_x = 110

LETTER_X_SPACING = 85
LETTER_Y_SPACING = 12
LETTER_SIZE = 75

guesses_count = 0

guesses = [[]] * 6

indicators = []

game_result = ""


RED = "red"
WHITE = "white"
BLACK = "black"
GREEN = "#6aaa64"
YELLOW = "#c9b458"
GREY = "#787c7e"
OUTLINE = "#d3d6da"
FILLED_OUTLINE = "grey"

CORRECT_WORD = random.choice(WORDS)

ALPHABET = ["QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"]

BG = pygame.image.load("../WORDLE/WORDLEBG.png")

def draw_text(text, font, color, surface, x, y):
    """
    This function draws the text letters to the screen.
    :return:
    """
    text_obj = font.render(text, True, color)
    text_rect = text_obj.get_rect(center=(x, y))
    surface.blit(text_obj, text_rect)

def main_menu():
    """
    This function displays the main menu.
    :return:
    """
    while True:
        SCREEN.blit(BG, (0,0))

        menu_rect = pygame.Rect(95, 80, 440, 35)
        pygame.draw.rect(SCREEN, 'black', menu_rect)

        draw_text("WORDLE MAIN MENU", GUESSED_LETTER_FONT, WHITE, SCREEN, WIDTH // 2, 100)

        button_play = pygame.Rect(200, 300, 200, 100)
        button_quit = pygame.Rect(200, 500, 200, 100)

        pygame.draw.rect(SCREEN, 'white', button_play)
        pygame.draw.rect(SCREEN, 'white', button_quit)

        draw_text("PLAY", GUESSED_LETTER_FONT, BLACK, SCREEN, button_play.centerx, button_play.centery)
        draw_text("QUIT", GUESSED_LETTER_FONT, BLACK, SCREEN, button_quit.centerx, button_quit.centery)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = event.pos
                if button_play.collidepoint(mouse_pos):
                    return "play"
                if button_quit.collidepoint(mouse_pos):
                    pygame.quit()
                    sys.exit()

        pygame.display.update()


def game():
    """
    This function is my game.
    :return:
    """
    BACKGROUND = pygame.image.load("../WORDLE/Tiles.png")
    BACKGROUND_RECT = BACKGROUND.get_rect(center=(317, 300))

    pygame.display.set_caption("Wordle Remake")

    SCREEN.fill("black")
    SCREEN.blit(BACKGROUND, BACKGROUND_RECT)

    button_back = pygame.Rect(15, 15, 75, 55)
    pygame.draw.rect(SCREEN, 'red', button_back)

    draw_text("GO BACK", BACK_LETTER_FONT, BLACK, SCREEN, button_back.centerx, button_back.centery)

    pygame.display.update()

    class Letter:
        def __init__(self, text, bg_position) -> None:
            self.bg_color = "white"
            self.text_color = "black"
            self.bg_position = bg_position
            self.bg_x = bg_position[0]
            self.bg_y = bg_position[1]
            self.bg_rect = (bg_position[0], self.bg_y, LETTER_SIZE, LETTER_SIZE)
            self.text = text
            self.text_position = (self.bg_x + 36, self.bg_position[1] + 34)
            self.text_surface = GUESSED_LETTER_FONT.render(self.text, True, self.text_color)
            self.text_rect = self.text_surface.get_rect(center=self.text_position)

        def draw(self) -> None:
            """
            This function draws the guessed words to the screen.
            :return:
            """
            pygame.draw.rect(SCREEN, self.bg_color, self.bg_rect)
            if self.bg_color == "white":
                pygame.draw.rect(SCREEN, FILLED_OUTLINE, self.bg_rect, 3)
            self.text_surface = GUESSED_LETTER_FONT.render(self.text, True, self.text_color)
            SCREEN.blit(self.text_surface, self.text_rect)
            pygame.display.update()

        def delete(self) -> None:
            """
            This function deletes the guesses on the screen.
            :return:
            """
            pygame.draw.rect(SCREEN, "white", self.bg_rect)
            pygame.draw.rect(SCREEN, OUTLINE, self.bg_rect, 3)
            pygame.display.update()

    class Indicator:
        def __init__(self, x, y, letter) -> None:
            self.x = x
            self.y = y
            self.text = letter
            self.rect = (self.x, self.y, 57, 75)
            self.bg_color = OUTLINE

        def draw(self) -> None:
            """
            This function draws the indicators to the screen.
            :return:
            """
            pygame.draw.rect(SCREEN, self.bg_color, self.rect)
            self.text_surface = AVAILABLE_LETTER_FONT.render(self.text, True, "white")
            self.text_rect = self.text_surface.get_rect(center=(self.x + 27, self.y + 30))
            SCREEN.blit(self.text_surface, self.text_rect)
            pygame.display.update()

    indicator_x, indicator_y = 20, 600

    for i in range(3):
        for letter in ALPHABET[i]:
            new_indicator = Indicator(indicator_x, indicator_y, letter)
            indicators.append(new_indicator)
            new_indicator.draw()
            indicator_x += 60
        indicator_y += 100
        if i == 0:
            indicator_x = 50
        elif i == 1:
            indicator_x = 105

    def check_guess(guess_to_check) -> str:
        """
        This function checks the guess and makes the words green, yellow, or grey.
        :return:
        """
        global current_guess, current_guess_string, guesses_count, current_letter_bg_x, game_result, attempts_counter, wins
        game_decided = False
        displayed_word = ""
        for i in range(5):
            lowercase_letter = guess_to_check[i].text.lower()
            if lowercase_letter in CORRECT_WORD:
                if lowercase_letter == CORRECT_WORD[i]:
                    guess_to_check[i].bg_color = GREEN
                    displayed_word += lowercase_letter
                    for indicator in indicators:
                        if indicator.text == lowercase_letter.upper():
                            indicator.bg_color = GREEN
                            indicator.draw()
                    guess_to_check[i].text_color = "white"
                    if not game_decided:
                        game_result = "YOU WON PROFESSOR"
                        wins += 1
                else:
                    if lowercase_letter in displayed_word:
                        guess_to_check[i].bg_color = GREY
                        displayed_word += lowercase_letter
                    else:
                        guess_to_check[i].bg_color = YELLOW
                    for indicator in indicators:
                        if indicator.text == lowercase_letter.upper():
                            indicator.bg_color = YELLOW
                            indicator.draw()
                    guess_to_check[i].text_color = "white"
                    game_result = ""
                    game_decided = True
            else:
                guess_to_check[i].bg_color = GREY
                for indicator in indicators:
                    if indicator.text == lowercase_letter.upper():
                        indicator.bg_color = GREY
                        indicator.draw()
                guess_to_check[i].text_color = "white"
                game_result = ""
                game_decided = True
            guess_to_check[i].draw()
            pygame.display.update()

        guesses_count += 1
        current_guess = []
        current_guess_string = ""
        current_letter_bg_x = 110

        if guesses_count == 6 and game_result == "":
            attempts_counter[guesses_count] = 0
            game_result = "YOU LOST PROFESSOR"

        elif game_result != "":
            attempts_counter[guesses_count] += 1
            show_leaderboard()
            write_to_file()
            play_again()



    def play_again() -> None:
        """
        Use this function to play the game again after winning or losing.
        :return:
        """
        pygame.draw.rect(SCREEN, 'black', (10, 600, 1000, 600))
        play_again_font = pygame.font.Font("../WORDLE/ConcertOne-Regular.ttf", 40)
        play_again_text = play_again_font.render("Press ENTER to play again!", True, "white")
        play_again_rect = play_again_text.get_rect(center=(WIDTH / 2, 700))
        word_was_text = play_again_font.render(f'The word was {CORRECT_WORD}!', True, "white")
        word_was_rect = word_was_text.get_rect(center=(WIDTH / 2, 750))
        SCREEN.blit(word_was_text, word_was_rect)
        SCREEN.blit(play_again_text, play_again_rect)
        pygame.display.update()


        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        reset()
                        return


    def reset() -> None:
        """
        This function restarts the screen when play_again is initiated.
        :return:
        """
        global guesses_count, CORRECT_WORD, guesses, current_guess, current_guess_string, game_result
        SCREEN.fill('black')
        SCREEN.blit(BACKGROUND, BACKGROUND_RECT)
        button_back = pygame.Rect(15, 15, 75, 55)
        pygame.draw.rect(SCREEN, 'red', button_back)
        draw_text("GO BACK", BACK_LETTER_FONT, BLACK, SCREEN, button_back.centerx, button_back.centery)
        pygame.display.update()
        guesses_count = 0
        CORRECT_WORD = random.choice(WORDS)
        guesses = [[]] * 6
        current_guess = []
        current_guess_string = ""
        game_result = ""
        pygame.display.update()
        for indicator in indicators:
            indicator.bg_color = OUTLINE
            indicator.draw()



    def create_new_letter() -> None:
        """
        This function adds a letter to your guess when a key on the keyboard is pressed.
        :return:
        """
        global current_guess_string, current_letter_bg_x
        current_guess_string += key_pressed
        new_letter = Letter(key_pressed, (current_letter_bg_x, guesses_count * 100 + LETTER_Y_SPACING))
        current_letter_bg_x += LETTER_X_SPACING
        guesses[guesses_count].append(new_letter)
        current_guess.append(new_letter)
        for guess in guesses:
            for letter in guess:
                letter.draw()

    def delete_letter() -> None:
        """
        This function deletes a letter to your guess when backspace on the keyboard is pressed.
        :return:
        """
        global current_guess_string, current_letter_bg_x
        guesses[guesses_count][-1].delete()
        guesses[guesses_count].pop()
        current_guess_string = current_guess_string[:-1]
        current_guess.pop()
        current_letter_bg_x -= LETTER_X_SPACING

    def show_leaderboard() -> None:
        """
        This function shows the leaderboard score when you win.
        :return:
        """
        leaderboard_font = pygame.font.Font(None, 40)
        SCREEN.fill(BLACK)
        draw_text("Wordle Guess Leaderboard", leaderboard_font, WHITE, SCREEN, WIDTH // 2, 50)
        y = 150
        for attempt, count in attempts_counter.items():
            text = f"Attempt {attempt}: {count}"
            draw_text(text, leaderboard_font, WHITE, SCREEN, WIDTH // 2, y)
            y += 75
        pygame.display.update()

    def write_to_file() -> None:
        """
        This function writes the leaderboard score to a file.
        :return:
        """
        with open("stored_WORDLE_Wins", "w") as file_wins:
            new = str(attempts_counter)
            file_wins.write("WORDLE LEADER BOARD SCORE\n")
            file_wins.write(new)


    in_leaderboard = False

    while True:
        if game_result != "":
            play_again()
            if not in_leaderboard:
                in_leaderboard = True
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = event.pos
                if button_back.collidepoint(mouse_pos):
                    return "back"
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    if game_result != "":
                        reset()
                        in_leaderboard = False
                    else:
                        if len(current_guess_string) == 5 and current_guess_string.lower() in WORDS:
                            check_guess(current_guess)
                            if game_result != "":
                                if guesses_count == 8:
                                    reset()
                                    in_leaderboard = False
                elif event.key == pygame.K_BACKSPACE:
                    if len(current_guess_string) > 0:
                        delete_letter()
                else:
                    key_pressed = event.unicode.upper()
                    if key_pressed in "QWERTYUIOPASDFGHJKLZXCVBNM" and key_pressed != "":
                        if len(current_guess_string) < 5:
                            create_new_letter()


def main() -> None:
    """
    This function runs the start of the game.
    :return:
    """
    while True:
        action = main_menu()
        if action == "play":
            result = game()
            if result == "back":
                continue
        elif action == "quit":
            pygame.quit()
            sys.exit()



if __name__ == "__main__":
    main()


